import App from "./components/App";
import './styles.css';